<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MarketDay extends Model
{
    protected $table = 'market_day';
    public $timestamps = false;



}