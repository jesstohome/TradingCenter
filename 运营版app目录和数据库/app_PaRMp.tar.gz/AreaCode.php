<?php
/**
 * create by vscode
 * @author lion
 */
namespace App;


use Illuminate\Database\Eloquent\Model;

class AreaCode extends Model
{
    protected $table = 'area_code';
    public $timestamps = false;

}
