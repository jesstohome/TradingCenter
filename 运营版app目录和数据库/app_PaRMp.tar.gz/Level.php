<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Seller;

class Level extends Model
{
    protected $table = 'level';
    public $timestamps = false;



}
