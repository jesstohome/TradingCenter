<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Seller;

class Algebra extends Model
{
    protected $table = 'algebra';
    public $timestamps = false;



}
