<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LbxHash extends Model
{
    protected $attributes = [
        'status' => 0,
    ];
}
