<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BindBoxCollect extends Model
{
    protected $table = 'bind_box_collect';
    public $timestamps = false;

}
