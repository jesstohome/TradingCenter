<?php
namespace App\Http\Controllers\Manages;

use Illuminate\Routing\Controller;

class Base extends Controller
{



}