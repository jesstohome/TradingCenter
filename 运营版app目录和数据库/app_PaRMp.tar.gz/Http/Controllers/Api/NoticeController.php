<?php


namespace App\Http\Controllers\Api;



class NoticeController extends Controller
{
    
}
