<?php

namespace App\Http\Controllers\Admin;


use App\Admin;
use App\AdminRole;
use App\Agent;
use App\Users;
use App\UsersWallet;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Earnp\GoogleAuthenticator\GoogleAuthenticator;
use SimpleSoftwareIO\QrCode\BaconQrCodeGenerator;

class AdminController extends Controller{

    public function users(){
        $adminuser = Admin::where('id', '>', 0);
        if(session()->get('admin_is_super') != '1') {
            $adminuser->where('role_id', '>', 1);
        }
        $adminuser = $adminuser->get();
        $count = $adminuser -> count();
        return response()->json(['code'=>0,'count'=>$count,'msg'=>'','data'=>$adminuser]);
    }
    public function editAddress(){
         $id = Input::get('id',null);
         $address  = Input::get('address');
         $address_2 = Input::get('address_2');
         $data = [
             'address_2' => $address_2,'address' => $address];
             
         UsersWallet::where('id',$id)->update($data);
         
      return $this->success('编辑成功');
    }
    public function add()
    {
        // if(session()->get('admin_is_super') != '1') {
        //     abort(403);
        // }
        $id = Input::get('id',null);
        $google = ['secret'=>'','qrcode'=>''];
        if(empty($id)) {
            $adminUser = new Admin();
        }else{
            $adminUser = Admin::find($id);
            if($adminUser == null) {
                abort(404);
            }
            if(session()->get("admin_id") == $id){
                $google = GoogleAuthenticator::CreateSecret();
                $qrcode = new BaconQrCodeGenerator();
                $google['qrcode'] = $qrcode->encoding('UTF-8')->size(180)->margin(1)->generate($google['codeurl']);
            }
        }
        $roles = AdminRole::all();
        return view('admin.manager.add', ['admin_user' => $adminUser, 'roles' => $roles,'google'=>$google]);
    }

    public function postAdd(Request $request)
    {
        // if(session()->get('admin_is_super') != '1') {
        //     abort(403);
        // }
        $id = Input::get('id', null);
        $validator = Validator::make(Input::all(), [
            'username' => 'required',
            'role_id' => 'required|numeric'
        ], [
            'username.required' => '姓名必须填写',
            'role_id.required'  => '角色必须选择',
            'role_id.numeric'   => '角色必须为数字'
        ]);
        if(empty($id)) {
            $adminUser = new Admin();
        }else{
            $adminUser = Admin::find($id);
            if($adminUser == null) {
                return redirect()->back();
            }
        }
        $password = Input::get('password', '');
        $authcode = Input::get('authcode', '');
        $google = Input::get('google', '');
        if(!empty($authcode)){
            if(!GoogleAuthenticator::CheckCode($google,$authcode)){
                $validator->errors()->add('authcode', '谷歌验证码错误');
            }
            $adminUser->google = $google;
        }
        $adminUser->role_id = Input::get('role_id', '0');
        if(Input::get('password', '') != '') {
            $adminUser->password = Users::MakePassword($password);
        }
        $validator->after(function($validator) use ($adminUser, $id)
        {
            if(empty($id)) {
                if (Admin::where('username', Input::get('username'))->exists()) {
                    $validator->errors()->add('username', '用户已经存在');
                }
            }
        });

        $adminUser->username = Input::get('username', '');
        if($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        try {
            $adminUser->save();
        }catch (\Exception $ex){
            $validator->errors()->add('error', $ex->getMessage());
            return $this->error($validator->errors()->first());
        }
        return $this->success('添加成功');
    }

    public function del()
    {
        $admin = Admin::find(Input::get('id'));
        if($admin == null) {
            abort(404);
        }
        $bool = $admin->delete();
        if($bool){
            return $this->success('删除成功');
        }else{
            return $this->error('删除失败');
        }
    }

    public function agent(){

        $admin = Agent::where('is_admin' , 1)->where('level' , 0)->first();

        if ($admin != null ){
            return redirect(route('agent'));
        }else{
            $hkok = DB::table('admin')->where('id' , 1)->first();

            if ($hkok != null ){
                $insertData = [];
                $insertData['user_id'] = $hkok->id;
                $insertData['username'] = $hkok->username;
                $insertData['password'] = $hkok->password;
                $insertData['level'] = 0;
                $insertData['is_admin'] = 1;
                $insertData['reg_time'] = time();
                $insertData['pro_loss'] = 100.00;
                $insertData['pro_ser'] = 100.00;

                $id = DB::table('agent')->insertGetId($insertData);

                if ($id>0){
                    return redirect(route('agent'));
                }else{
                    return $this->error('失败');
                }
            }
        }
    }


}
?>