<?php

namespace App\Http;

use Illuminate\Foundation\Http\Kernel as HttpKernel;

class Kernel extends HttpKernel
{
    /**
     * The application's global HTTP middleware stack.
     *
     * These middleware are run during every request to your application.
     *
     * @var array
     */
    protected $middleware = [
        \Illuminate\Foundation\Http\Middleware\CheckForMaintenanceMode::class,
        \Illuminate\Foundation\Http\Middleware\ValidatePostSize::class,
        \App\Http\Middleware\TrimStrings::class,
        \Illuminate\Foundation\Http\Middleware\ConvertEmptyStringsToNull::class,
        \App\Http\Middleware\TrustProxies::class,
        // \App\Http\Middleware\EnableCrossRequestMiddleware::class,
        // \App\Http\Middleware\Cross::class
    ];

    /**
     * The application's route middleware groups.
     *
     * @var array
     */
    protected $middlewareGroups = [
        'web' => [
            \App\Http\Middleware\EncryptCookies::class,
            \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
            \Illuminate\Session\Middleware\StartSession::class,
            // \Illuminate\Session\Middleware\AuthenticateSession::class,
            \Illuminate\View\Middleware\ShareErrorsFromSession::class,
//            \App\Http\Middleware\VerifyCsrfToken::class,
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
        ],

        'api' => [
            'throttle:60,1',
            'bindings',
        ],
    ];

    /**
     * The application's route middleware.
     *
     * These middleware may be assigned to groups or used individually.
     *
     * @var array
     */
    protected $routeMiddleware = [
        'auth' => \Illuminate\Auth\Middleware\Authenticate::class,
        'auth.basic' => \Illuminate\Auth\Middleware\AuthenticateWithBasicAuth::class,
        'bindings' => \Illuminate\Routing\Middleware\SubstituteBindings::class,
        'can' => \Illuminate\Auth\Middleware\Authorize::class,
        'guest' => \App\Http\Middleware\RedirectIfAuthenticated::class,
        'throttle' => \Illuminate\Routing\Middleware\ThrottleRequests::class,
        'check_api' => \App\Http\Middleware\CheckApi::class,
        'lang' =>   \App\Http\Middleware\Language::class,
        'admin_auth' => \App\Http\Middleware\AdminAuthenticate::class,
        'agent_auth' => \App\Http\Middleware\AgentAuth::class,
        'check_user' => \App\Http\Middleware\CheckUser::class,
        'check_islock' => \App\Http\Middleware\IsLock::class,//添加判断是否锁定
        'cross' => \App\Http\Middleware\Cross::class,
        'lever_hold_check' => \App\Http\Middleware\HoldCheck::class,
        'demo_limit' => \App\Http\Middleware\DemoLimit::class,
        'validate_locked' => \App\Http\Middleware\ValidateUserLocked::class,
        'score_limit' => \App\Http\Middleware\ScoreLimit::class,
        'XSS' => \App\Http\Middleware\XSS::class,
    ];
}
