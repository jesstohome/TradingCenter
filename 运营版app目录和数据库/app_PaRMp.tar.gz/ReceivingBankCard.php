<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReceivingBankCard extends Model
{
    protected $table = 'receiving_bank_card';
    public $timestamps = false;
}